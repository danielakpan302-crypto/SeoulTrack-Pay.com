import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();
const app = express();
const port = Number(process.env.PORT || 3000);
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.disable("x-powered-by");
app.use(helmet());
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 200, standardHeaders: "draft-7", legacyHeaders: false }));

// This starter has no financial ledger or authentication. Do not enable money routes
// until a provider, database, authentication, signed webhooks, and audit logging exist.
app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", service: "SeoulTrack Pay API", financialFeatures: "disabled" });
});

app.post("/api/payments/initialize", (_req, res) => {
  res.status(503).json({
    error: "PAYMENTS_NOT_CONFIGURED",
    message: "Payments are disabled until a verified provider account and secure server integration are configured."
  });
});

app.post("/api/withdrawals", (_req, res) => {
  res.status(503).json({
    error: "WITHDRAWALS_NOT_CONFIGURED",
    message: "Withdrawals are disabled until authentication, a transactional ledger, PIN protection, and a verified payout provider are configured."
  });
});

app.post("/api/parcel/track", (_req, res) => {
  res.status(503).json({
    error: "CARRIER_NOT_CONFIGURED",
    message: "Parcel tracking is unavailable until a carrier API is configured."
  });
});

app.use((err, _req, res, _next) => {
  console.error("Request failed", err?.message || "unknown error");
  res.status(500).json({ error: "INTERNAL_ERROR", message: "An unexpected server error occurred." });
});

app.listen(port, () => {
  console.log(`SeoulTrack Pay server listening on port ${port}`);
});
