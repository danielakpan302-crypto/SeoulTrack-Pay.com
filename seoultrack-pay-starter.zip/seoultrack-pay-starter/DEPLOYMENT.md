# Deployment guide

## 1. Put the files on GitHub
1. Sign in to https://github.com on your phone.
2. Create a repository named `seoultrack-pay`.
3. Upload `index.html`, `server.js`, `package.json`, `.env.example`, `README.md`, and this file.
4. The `index.html` should be at the repository root for a static Netlify deployment. If deploying with the Node server, put the HTML file inside a folder named `public` (create the folder and move `index.html` into it).

## 2. Publish the interface
1. Sign in at https://www.netlify.com.
2. Import the GitHub repository and deploy the static interface.
3. This creates a public website URL, but it does not enable deposits, withdrawals, subscriptions, or tracking.

## 3. Deploy the API separately
Deploy `server.js` to a host that supports Node.js 20+. Use `npm install` for dependencies and `npm start` to run it. Set environment variables in the host dashboard, not in GitHub. Test `/api/health`.

## 4. Before real financial transactions
A live-money launch requires all of the following:
- A payment/payout provider that explicitly supports your registered business and customer countries.
- Completed provider business verification and approval for the intended use.
- Secure authentication, database-backed accounts, and a transactional double-entry ledger.
- Server-side payment initialization and signed webhook verification; never trust browser-only success messages.
- Idempotency and reconciliation to prevent duplicate credits.
- Secure withdrawal approval, risk controls, audit logs, and provider-confirmed payout status.
- Data protection, terms, privacy policy, customer support, and any required licenses/compliance review.

Until those pieces are implemented and tested, money-moving endpoints intentionally return a disabled status. Do not use real customer funds with this starter.
