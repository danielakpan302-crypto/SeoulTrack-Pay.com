# SeoulTrack Pay — starter project

This project packages the website interface you provided and a minimal API scaffold. It is **not yet a live financial service**.

## Included
- `index.html` — mobile-friendly website interface.
- `server.js` — small Express server with a health check and intentionally disabled money-moving routes.
- `package.json` — server dependencies and start script.
- `.env.example` — names of configuration values; never put real secrets in GitHub.
- `DEPLOYMENT.md` — phone-friendly deployment instructions and launch checklist.

## What currently works
- Navigation between sections.
- Currency conversion estimate via a public exchange-rate endpoint when available.
- Form validation and clear messages.

## What is intentionally NOT enabled
- Deposits, wallet balances, subscriptions charged to customers, or withdrawals.
- User registration/login or withdrawal PIN storage.
- Real parcel tracking.

The page must never show a payment as successful just because a user clicked a button. To enable real money movement, you must choose a payment/payout provider that supports your business and countries, complete its verification, configure private server-side credentials, implement signed webhooks and idempotency, and use a persistent transactional ledger. You will also need legal/compliance review for the countries and services you intend to support. Never commit API keys, secret keys, passwords, PINs, or customer data to GitHub.

## Run locally
1. Install Node.js 20 or newer on a computer.
2. In this folder, run `npm install`.
3. Copy `.env.example` to `.env` and set a strong `SESSION_SECRET` if you use sessions later.
4. Run `npm start`.
5. Open `http://localhost:3000`.

On a phone, the simplest first step is to upload these files to a GitHub repository. The static interface can be hosted by Netlify, but the server must be deployed to a Node-compatible host separately. Do not configure Netlify to treat the server as a static site.
